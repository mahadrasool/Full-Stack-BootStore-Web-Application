from django.apps import AppConfig


class BookstoreManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookstore_management'
